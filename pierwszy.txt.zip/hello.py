# def collatz(number):
#     if (number % 2) == 0:
#         number = number / 2
#         print(number)
#         return number
#     elif (number % 2) == 1:
#         number = number * 3 + 1
#         print(number)
#         return number
#
#
# while 1:
#     print('Podaj liczbe')
#     try:
#         a = int(input())
#         while a != 1:
#             a = collatz(a)
#     except ValueError:
#         print("Podaj liczbe calkowita")
from os import write

f = open("pierwszy.txt", "w+")

for i in range(10):
    f.write('This line nr is %d\r' % (i+1))


